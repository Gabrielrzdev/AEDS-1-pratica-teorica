/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: gabriel
 *
 * Created on 23 de abril de 2024, 23:34
 */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {

    char nome[30], sobrenome[30], nomecompleto[60];
    int op;

    // Definindo os nomes
    nome[0] = 'g';
    nome[1] = 'a';
    nome[2] = 'b';
    nome[3] = 'r';
    nome[4] = 'i';
    nome[5] = 'e';
    nome[6] = 'l';
    nome[7] = '\0';

    printf("\nNome: %s\n", nome);

    sobrenome[0] = 'r';
    sobrenome[1] = 'a';
    sobrenome[2] = 'm';
    sobrenome[3] = 'i';
    sobrenome[4] = 'r';
    sobrenome[5] = 'e';
    sobrenome[6] = 'z';
    sobrenome[7] = '\0';

    printf("\nSobrenome: %s\n", sobrenome);

    do {
        printf("1. Colocar os caracteres do nome completo em maiúsculas\n");
        printf("2. Colocar os caracteres em minúsculas, menos as primeiras letras do nome completo\n");
        printf("3. Retirar os espaços de um nome completo\n");
        printf("4. Procurar se um nome está dentro do nome completo\n");
        printf("0. Sair\n");
        scanf("%d", &op); // Lê a opção escolhida pelo usuário

        switch (op) {
            case 1: // Construindo o nome completo
                {
                    int i, j;
                    for (i = 0; nome[i] != '\0'; i++) {
                        nomecompleto[i] = nome[i];
                    }
                    for (j = 0; sobrenome[j] != '\0'; j++) {
                        nomecompleto[i + j] = sobrenome[j];
                    }
                    nomecompleto[i + j] = '\0';
                    printf("\nNome Completo: %s\n", nomecompleto);
                }
                break;

            case 2: // Colocando em maiúsculas
                {
                    int i;
                    for (i = 0; nomecompleto[i] != '\0'; i++) {
                        nomecompleto[i] = toupper(nomecompleto[i]);
                    }
                    printf("\nNome Completo: %s\n", nomecompleto);
                }
                break;

            case 3: // Colocando em minúsculas, exceto as primeiras letras
                {
                    int i;
                    for (i = 1; nomecompleto[i] != '\0'; i++) {
                        nomecompleto[i] = tolower(nomecompleto[i]);
                    }
                    printf("\nNome Completo: %s\n", nomecompleto);
                }
                break;

            case 4: // Procurando se um nome está dentro do nome completo
                {
                    char *result = strstr(nomecompleto, "and");
                    if (result != NULL) {
                        printf("\nO nome 'Gabriel' está presente no nome completo.\n");
                    } else {
                        printf("\nO nome 'Gabriel' não está presente no nome completo.\n");
                    }
                }
                break;

            case 0:
                printf("Saindo...\n");
                break;

            default:
                printf("Opcao invalida. Por favor, escolha uma opcao valida.\n"); // Mensagem de opção inválida
                break;
        }

    } while (op > 0 || op == 4 );

    return 0;
}

