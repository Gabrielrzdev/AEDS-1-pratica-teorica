/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.033
 *
 * Created on 25 de março de 2024, 16:20
 */

#include <cstdlib>
#include <stdio.h>


using namespace std;

/* ENDEREÇOS DE VARIÁVEIS, LIMITES INFERIOR E SUPERIOR TBAELA ASCII */


int main() { 
    int variavelint = 50;
    long int variavellongint = 50;
    short int variavelshortint = 50;
    unsigned int variavelunsignedint = 50;
    float variavelfloat = 50;
    double variaveldouble = 50;
    int proximo, anterior;
    
    
   
    
    
    
    
    printf ("\n\tTipos de Variáveis e Alocação de Memória \n\n");
    
    printf("\tVariável inteira: \n");
    printf("\t\tValor Armazenado: %ld\n", variavellongint);
    printf("\t\tEndereço na memória: %p\n", &variavellongint);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(long int));
    
    printf("\tVariável inteira: \n");
    printf("\t\tValor Armazenado: %i\n", variavelshortint);
    printf("\t\tEndereço na memória: %p\n", &variavelshortint);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(short int));
    
    printf("\tVariável inteira: \n");
    printf("\t\tValor Armazenado: %i\n", variavelunsignedint);
    printf("\t\tEndereço na memória: %p\n", &variavelunsignedint);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(unsigned int));
    
    
    printf("\tVariável inteira: \n");
    printf("\t\tValor Armazenado: %i\n", variavelint);
    printf("\t\tEndereço na memória: %p\n", &variavelint);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(int));

    
    printf("\tVariável Float: \n");
    printf("\t\tValor Armazenado: %f\n", variavelfloat);
    printf("\t\tEndereço na memória: %p\n", &variavelfloat);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(float));
    
    printf("\tVariável Float: \n");
    printf("\t\tValor Armazenado: %f\n", variaveldouble);
    printf("\t\tEndereço na memória: %p\n", &variaveldouble);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(float));
    
        anterior = -1;
        proximo = 0;
        while (proximo > anterior ) {
            anterior = proximo;
            proximo = proximo + 1; //proximo++;
        }
    printf("\t limite inferior: %d \t limite superior:%d", proximo, anterior); 
    
    unsigned char codigoASCII = 0;
    
    printf("\tTabela ASCII: \n");
    
    codigoASCII = 0;
    while ( codigoASCII < 255) {
        printf("\t\tCaracter: %c", codigoASCII);
        printf("\t\tcodigo: %d\n", codigoASCII);
        codigoASCII++;
        
        
    }
    
   
   

    return 0;
}

