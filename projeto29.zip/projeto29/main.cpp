/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.033
 *
 * Created on 29 de abril de 2024, 16:04
 */
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

const int TAM = 100;

typedef struct {
    bool válido;
    string nome;
    string celular;
    string cidade;
    string email;   
} Pessoa;

int main(int argc, char** argv) {
    
    Pessoa agenda[TAM];
    ifstream arquivo("agenda.txt");
    int qtde = 0;
    int i = 0;
    int opcao;
    string nome;
    int e =0;

    if (!arquivo) {
        cout << "Erro ao abrir o arquivo agenda.txt\n";
        return 1;
    }

    while (arquivo >> nome && nome != "fim") {
        agenda[i].nome = nome;
        arquivo >> agenda[i].celular;
        arquivo >> agenda[i].cidade;
        arquivo >> agenda[i].email;
        agenda[i].válido = true;
        i++;
    }
    
    arquivo.close();
    
    // Exemplo de como você pode usar os dados lidos:
    for (int j = 0; j < i; j++) {
        cout << "Nome: " << agenda[j].nome << endl;
        cout << "Celular: " << agenda[j].celular << endl;
        cout << "Cidade: " << agenda[j].cidade << endl;
        cout << "Email: " << agenda[j].email << endl;
        cout << endl;
    }
    
    //Opções de manipulação 
    do {
        cout << "\nDigite o número referente ao que deseja realizar:" << endl;
        cout << "1 - Buscar um contato." << endl; 
        cout << "2 - Adicionar um contato." << endl; 
        cout << "3 - Remover um contato." << endl; 
        cout << "0 - Sair." << endl; 
        cout << "Opção: ";
        cin >> opcao; 

        switch(opcao) { 
            case 0:
                break; 
            // Buscar um contato 
            case 1: 
                cout << "\nDigite o nome do contato que deseja buscar: "; 
                cin >> nome; 
                cout << endl; 
                e = 0; 
                for (int k = 0; k < i; k++) { 
                    if (nome == agenda[k].nome) { 
                        e = 1; 
                        cout << "Nome: " << agenda[k].nome << endl;
                        cout << "Celular: " << agenda[k].celular << endl;
                        cout << "Cidade: " << agenda[k].cidade << endl;
                        cout << "Email: " << agenda[k].email << endl;
                        cout << endl;
                    } 
                } 
                if(e == 0) { 
                    cout << "O contato não está na agenda." << endl; 
                } 
                break; 
            // Adicionar um contato 
            case 2: 
                if(i == TAM) { 
                    cout << "A agenda está cheia. Remova um contato antes de adicionar outro." << endl;
                } else { 
                    cout << "Digite as informações do contato." << endl; 
                    cout << "Nome: "; 
                    cin >> agenda[i].nome; 
                    cout << "Celular: "; 
                    cin >> agenda[i].celular; 
                    cout << "Cidade: "; 
                    cin >> agenda[i].cidade; 
                    cout << "Email: "; 
                    cin >> agenda[i].email;
                    agenda[i].válido = true;
                    i++;
                } 
                break; 
            // Remover um contato 
            case 3: 
                cout << "Digite o nome do contato que deseja remover: "; 
                cin >> nome; 
                e = 0; 
                for (int k = 0; k < i && e == 0; k++) { 
                    if (nome == agenda[k].nome) { 
                        e = 1; 
                        for(int l = k; l < i - 1; l++) { 
                            agenda[l] = agenda[l + 1]; 
                        }
                        i--;
                    } 
                } 
                if(e == 0) { 
                    cout << "O contato não está na agenda." << endl; 
                } 
                break;
        } 
    } while(opcao != 0); 

    // Atualizar o arquivo com os dados da agenda
    ofstream arquivo_saida("agenda.txt");
    if (!arquivo_saida) {
        cout << "Erro ao abrir o arquivo de saída agenda.txt\n";
        return 1;
    }
    for (int j = 0; j < i; j++) {
        arquivo_saida << agenda[j].nome << " " << agenda[j].celular << " " << agenda[j].cidade << " " << agenda[j].email << endl;
    }
    arquivo_saida << "fim"; // Marca o fim do arquivo
    arquivo_saida.close();
    
    return 0; 
}


