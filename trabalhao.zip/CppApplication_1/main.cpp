/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: gabriel Ramirez Matricula 2024.1.08.033
 *
 * Created on 12 de abril de 2024, 16:59
 */
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <ctime>

using namespace std;

int main(int argc, char** argv) {
    const int NUM = 100;
    int opcao, valor[NUM], i, resposta, contador[NUM], x;
    int limitf, limitsup, conta, aux, j;

    srand(time(NULL));

    for (i = 0; i < NUM; i++) {
        valor[i] = rand() % 101 + 100;
    }

    do {
        cout << "\t\t BUSCA DE VETORES" << endl
             << endl;
        cout << " 0 - sair" << endl;
        cout << " 1 - informa se um valor existe no vetor, e qual sua posição" << endl;
        cout << " 2 - conta quantas vezes um valor aparece em um vetor, e quais suas posições" << endl;
        cout << " 3 - conta quantas vezes os valores de um intervalo aparecem no vetor" << endl;
        cout << " 4 - inverte os valores de um vetor" << endl;
        cout << " 5 - retira do vetor todas as ocorrências de um valor" << endl;
        cout << " 6 - retira do vetor todos os valores repetidos" << endl;
        cout << " Escolha uma opção do menu de busca: ";
        cin >> opcao;
        cout << endl;

        switch (opcao) {
            case 1:
                cout << "Informe um valor: ";
                cin >> resposta;
                for (i = 0; i < NUM; i++) {
                    if (valor[i] == resposta) {
                        cout << "O valor existe e sua posição é " << i + 1 << "ª" << endl;
                        break; // Se encontrou o valor, pode parar de procurar
                    }
                }
                if (i == NUM) {
                    cout << "O valor não existe no vetor" << endl;
                }
                break;

            case 2:
                cout << "Informe um valor: ";
                cin >> resposta;
                x = 0;
                for (i = 0; i < NUM; i++) {
                    if (valor[i] == resposta) {
                        contador[x] = i + 1;
                        x++;
                    }
                }
                cout << "O valor aparece " << x << " vezes, nas posições: ";
                for (i = 0; i < x; i++) {
                    cout << contador[i] << " ";
                }
                cout << endl;
                break;

            case 3:
                cout << "Informe o valor do limite inferior: ";
                cin >> limitsup;
                cout << "Informe o valor do limite superior: ";
                cin >> limitf;
                conta = 0;
                for (i = 0; i < NUM; i++) {
                    if (valor[i] >= limitsup && valor[i] <= limitf) {
                        conta++;
                    }
                }
                cout << "A quantidade de valores no intervalo [" << limitsup << ", " << limitf << "] é: " << conta << endl;
                break;
            case 4:
                // Inverter os valores do vetor
                for (i = 0; i < NUM / 2; ++i) {
                    swap(valor[i], valor[NUM - i - 1]);
                }
                cout << "Valores do vetor invertidos." << endl;
                break;

            case 5:
                cout << "Informe o valor a ser retirado do vetor: ";
                cin >> resposta;
                aux = 0;
                for (i = 0; i < NUM; i++) {
                    if (valor[i] != resposta) {
                        valor[aux++] = valor[i];
                    }
                }
                cout << "Valor(es) removido(s) do vetor." << endl;
                break;

            case 6:
                for (i = 0; i < NUM; ++i) {
                    for (j = i + 1; j < NUM;) {
                        if (valor[i] == valor[j]) {
                            for (int k = j; k < NUM - 1; k++) {
                                valor[k] = valor[k + 1];
                            }
                            
                        } else {
                            j++;
                        }
                    }
                }
                cout << "Valores repetidos removidos do vetor." << endl;
                break;

        }
    } while (opcao != 0);

    return 0;
}
