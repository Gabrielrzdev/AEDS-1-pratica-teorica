/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   operacoes_matriz.c
 * Author: gabriel
 *
 * Created on 16 de junho de 2024, 21:18
 */

#ifndef OPERACOES_MATRIZ_C
#define OPERACOES_MATRIZ_C

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* OPERACOES_MATRIZ_C */

