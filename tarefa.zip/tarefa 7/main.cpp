/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: gabriel
 *
 * Created on 16 de junho de 2024, 19:09
 */
#include <stdio.h>
#include "operações_matriz.h"

void imprimirMatriz(int matriz[LINHAS][COLUNAS]);

int main() {
    int matriz1[LINHAS][COLUNAS] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    int matriz2[LINHAS][COLUNAS] = {
        {9, 8, 7},
        {6, 5, 4},
        {3, 2, 1}
    };

    int resultado[LINHAS][COLUNAS];
    int transposta[COLUNAS][LINHAS];

    // Encontrar a transposta de matriz1
    transporMatriz(matriz1, transposta);
    printf("Transposta de matriz1:\n");
    for (int i = 0; i < COLUNAS; i++) {
        for (int j = 0; j < LINHAS; j++) {
            printf("%d ", transposta[i][j]);
        }
        printf("\n");
    }

    // Somar matriz1 e matriz2
    somarMatrizes(matriz1, matriz2, resultado);
    printf("Soma de matriz1 e matriz2:\n");
    imprimirMatriz(resultado);

    // Multiplicar matriz1 e matriz2
    multiplicarMatrizes(matriz1, matriz2, resultado);
    printf("Produto de matriz1 e matriz2:\n");
    imprimirMatriz(resultado);

    // Calcular o valor médio dos valores da primeira matriz
    double media = valorMedio(matriz1);
    printf("Valor médio dos valores de matriz1: %.2f\n", media);

    return 0;
}

void imprimirMatriz(int matriz[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }
}
