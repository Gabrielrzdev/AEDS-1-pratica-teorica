/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   operações_matriz.h
 * Author: gabriel
 *
 * Created on 16 de junho de 2024, 21:17
 */

#ifndef OPERACOES_MATRIZ_H
#define OPERACOES_MATRIZ_H

// Define o tamanho das matrizes
#define LINHAS 3
#define COLUNAS 3

// Declaração das funções
void transporMatriz(int matriz[LINHAS][COLUNAS], int resultado[COLUNAS][LINHAS]);
void somarMatrizes(int matriz1[LINHAS][COLUNAS], int matriz2[LINHAS][COLUNAS], int resultado[LINHAS][COLUNAS]);
void multiplicarMatrizes(int matriz1[LINHAS][COLUNAS], int matriz2[LINHAS][COLUNAS], int resultado[LINHAS][COLUNAS]);
double valorMedio(int matriz[LINHAS][COLUNAS]);

#endif