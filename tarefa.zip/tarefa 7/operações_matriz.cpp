/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include "operações_matriz.h"

// Função para encontrar a transposta de uma matriz
void transporMatriz(int matriz[LINHAS][COLUNAS], int resultado[COLUNAS][LINHAS]) {
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            resultado[j][i] = matriz[i][j];
        }
    }
}

// Função para somar duas matrizes
void somarMatrizes(int matriz1[LINHAS][COLUNAS], int matriz2[LINHAS][COLUNAS], int resultado[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }
}

// Função para multiplicar duas matrizes
void multiplicarMatrizes(int matriz1[LINHAS][COLUNAS], int matriz2[LINHAS][COLUNAS], int resultado[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            resultado[i][j] = 0;
            for (int k = 0; k < COLUNAS; k++) {
                resultado[i][j] += matriz1[i][k] * matriz2[k][j];
            }
        }
    }
}

// Função para calcular o valor médio dos valores da primeira matriz
double valorMedio(int matriz[LINHAS][COLUNAS]) {
    int soma = 0;
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            soma += matriz[i][j];
        }
    }
    return (double)soma / (LINHAS * COLUNAS);
}