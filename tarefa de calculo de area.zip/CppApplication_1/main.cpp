/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: gabriel Ramirez Matricula 2024.1.08.033
 *
 * Created on 4 de abril de 2024, 16:59
 */

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

// Funções para calcular a área e o volume dos objetos geométricos
double calcularAreaQuadrado(double lado) {
    return lado * lado;
}

double calcularAreaRetangulo(double base, double altura) {
    return base * altura;
}

double calcularVolumeCubo(double lado) {
    return lado * lado * lado;
}

double calcularVolumeParalelepipedo(double base, double altura, double profundidade) {
    return base * altura * profundidade;
}

// Função para escrever os objetos geométricos no arquivo
void escreverObjeto(ofstream& arquivo, const string& nome, double parametro1, double parametro2 = 0) {
    arquivo << nome << " " << parametro1 << " " << parametro2 << endl;
}

int main() {
    ofstream arquivo("cenagrafica.txt");
    if (!arquivo) {
        cerr << "Erro ao abrir o arquivo cenagrafica.txt" << endl;
        return 1;
    }

    cout << "Digite os objetos geométricos (nome e parâmetros separados por espaços):" << endl;

    string nome;
    double areaTotal = 0.0;
    double volumeTotal = 0.0;

    while (true) {
        cin >> nome;
        if (nome == "fim") break;

        if (nome == "quadrado") {
            double lado;
            cin >> lado;
            escreverObjeto(arquivo, nome, lado);
            areaTotal += calcularAreaQuadrado(lado);
        } else if (nome == "retangulo") {
            double base, altura;
            cin >> base >> altura;
            escreverObjeto(arquivo, nome, base, altura);
            areaTotal += calcularAreaRetangulo(base, altura);
        } else if (nome == "cubo") {
            double lado;
            cin >> lado;
            escreverObjeto(arquivo, nome, lado);
            volumeTotal += calcularVolumeCubo(lado);
        } else if (nome == "paralelepipedo") {
            double base, altura, profundidade;
            cin >> base >> altura >> profundidade;
            escreverObjeto(arquivo, nome, base, altura);
            volumeTotal += calcularVolumeParalelepipedo(base, altura, profundidade);
        } else {
            cout << "Objeto não reconhecido: " << nome << endl;
        }
    }

    arquivo << "fim" << endl;
    arquivo.close();

    cout << "Área total: " << areaTotal << endl;
    cout << "Volume total: " << volumeTotal << endl;

    return 0;
}
