/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Filipe Carvalho
 *
 * Created on 5 de março de 2024, 16:24
 */

#include <cstdlib>
#include <stdio.h>

using namespace std;

/*
 *Esse projeto calcula o IMC de uma pessoa 
 */ 
int main(int argc, char** argv) {
    
    //declara as variáveis
    float altura, peso, imc;
    
    //adquire as informações do usuário
    printf("Para que seu Índice de Massa Corporal seja calculado, insira as seguintes informações.\n");
            
    printf("\nInsira a sua altura em metros: ");
    scanf(" %f", &altura);
    while ( altura < 0||altura> 3.00 ){
    printf("Valor incorreto.Digite novamente:");
    scanf (" %f, &altura");
    }
    
    printf("\nInsira o seu peso em quilogramas: ");
    scanf(" %f", &peso);
    while ( peso <0||peso> 300){
    printf(" Valor incorreto.Digite novamente:");
    scanf( " %f , &peso");
    }
    
    //calcula o IMC
    imc = peso/(altura*altura);
    
    //printa os resultados
    printf("\nSeu IMC é: %.2f ", imc);
    
    //informa a classificação do IMC calculado
    if (imc <= 18.5) {
        printf("\nSeu IMC corresponde à categoria \"abaixo do peso\"");
    } else 
        if (imc < 25) {
            printf("\nSeu IMC corresponde à categoria \"peso ideal\"");
        } else 
            if (imc < 30) {
                printf("\nSeu IMC corresponde à categoria \"levemente acima do peso\"");
            } else printf("\nSeu IMC corresponde à categoria \"obesidade (o grau não é especificado)\"");
                
    return 0;
}
 
