/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.033
 *
 * Created on 26 de março de 2024, 16:26
 */

#include <time.h>
#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    int segredo, chute;
    
    cout<<"Número Aleatório."<<endl;
    
    srand(time(NULL));
    segredo= 1+rand( )%100;
    
    cout<< "Advinhe o numero gerado"<<endl;
    cin>> chute;
    while (chute != segredo){
        
    
        if (chute > segredo) {
            cout<< " O numero gerado é maior que o chute"<<endl;
            cout<< "Tente novamente"<<endl;
            cin >>chute; 
    
    
        }else {
            cout<< " O numero é menor que o chute"<<endl;
            cout<< "tente novamente"<<endl;
            cin>>chute;
        }
       
    }
        
    cout<<"parabéns você acertou"<<endl;
    
     
   
                           

    return 0;
}

