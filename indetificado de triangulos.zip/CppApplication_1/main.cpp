#include <stdio.h>
#include <cstdlib>

using namespace std;

/*

 */
int main(int argc, char** argv) {
    int a, b, c;
    
    printf("Digite lado A do triangulo: ");
    scanf("%d",&a);
    
     printf("Digite lado B do triangulo: ");
    scanf("%d",&b);
    
     printf("Digite lado C do triangulo: ");
    scanf("%d",&c);
    
    if(a + b <= c || c + a <= b || b+c <= a){
        printf ("não é um triangulo");
    }
    if (a==b && b==c && c==a){
        printf("O triangulo é equilatero");
    }
    if (a==b ||b==c ||c==a){
        printf ("O triangulo é isosceles");            
    }
    if (a*a + b*b==c*c ||b*b+c*c==a*a||c*c==a*a==b*b){
        printf("O triangulo é retangulo\n");
    }
    if (a != b && c != a && b != c){
        printf("O triangulo é escaleno");
    }
   
    
    
    
    

  


    return 0;
}

